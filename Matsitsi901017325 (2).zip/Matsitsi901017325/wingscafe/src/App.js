import React from 'react';
import WingsCafeInventorySystem from './WingsCafeInventorySystem';
import './App.css';

const App = () => {
  return (
    <div>
      <WingsCafeInventorySystem />
    </div>
  );
};

export default App;
