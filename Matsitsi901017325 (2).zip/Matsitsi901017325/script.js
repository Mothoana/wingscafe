
function login() {
    const username = document.getElementById('username').value;

    if (username) {
        document.getElementById('user-management').style.display = 'none';
        document.getElementById('product-management').style.display = 'block';
        loadProducts();
    } else {
        alert('Please enter a username.');
    }
}

function addProduct(event) {
    event.preventDefault();

    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const category = document.getElementById('product-category').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const quantity = parseInt(document.getElementById('product-quantity').value);

    let products = JSON.parse(localStorage.getItem('products')) || [];
    
    const newProduct = { name, description, category, price, quantity };
    
    products.push(newProduct);
    
    localStorage.setItem('products', JSON.stringify(products));
    
    loadProducts();
    
    document.getElementById('product-form').reset();
}


function loadProducts() {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    
    const productList = document.getElementById('product-list');
    
    productList.innerHTML = '';
    
    products.forEach((product, index) => {
        const li = document.createElement('li');
        li.className = 'product-item';
        
        li.innerHTML = `
            ${product.name} - ${product.description} - $${product.price.toFixed(2)} - Quantity: ${product.quantity}
            <button onclick="editProduct(${index})">Edit</button>
            <button onclick="deleteProduct(${index})">Delete</button>
        `;
        
        productList.appendChild(li);
    });
}


function editProduct(index) {
    let products = JSON.parse(localStorage.getItem('products')) || [];
    
    const product = products[index];
    
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-description').value = product.description;
    document.getElementById('product-category').value = product.category;
    document.getElementById('product-price').value = product.price.toFixed(2);
    document.getElementById('product-quantity').value = product.quantity;

    
     deleteProduct(index);
}

function deleteProduct(index) {
   let products = JSON.parse(localStorage.getItem('products')) || [];
   products.splice(index, 1);
   localStorage.setItem('products', JSON.stringify(products)); 
   loadProducts();
}